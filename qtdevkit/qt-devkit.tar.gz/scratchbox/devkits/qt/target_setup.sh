target_root="$1";
DEVKIT_NAME="qt";
DEVKIT_DIR=$(dirname $(dirname $(readlink -f "$0"`)));
